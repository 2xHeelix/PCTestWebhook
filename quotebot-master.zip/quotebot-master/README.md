quotebot
========

the quotebot webhooks for slack
